CONFIG_PATH = '/home/maksim/Documents/uni/zoo_app/src/db_config.json'
