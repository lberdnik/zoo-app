from src.app.navigation import Navigation


class App:
    def start(self):
        navigation = Navigation()

        while True:
            command = input("Enter your command: ")
            if command == 'user':
                navigation.user_class()
            elif command == 'animals':
                navigation.animal()
            elif command == 'animal class':
                navigation.animal_class()
            elif command == 'animal food':
                navigation.animal_food()
            elif command == 'complex':
                navigation.complex()
            elif command == 'kind':
                navigation.kind()
            elif command == 'job':
                navigation.job()
            elif command == 'employee':
                navigation.employee()
            elif command == 'placement':
                navigation.placement()
            elif command == 'food':
                navigation.animal_food()
            elif command == 'exit':
                exit()
            else:
                print("Invalid command!")



App().start()
