import psycopg2.errors

from src.entities import User, Admin, Orders, Complex


class LoginPage:
    _user = None
    _user_id = None
    role: str = ''
    _is_success: bool = False

    def __init__(self):
        self._user = User()

    def _choose_role(self):
        while True:
            self.role = input('Enter your role(admin, user): ')
            if self.role == 'admin':
                self._user = Admin()
            elif self.role == 'user':
                self._user = User()
            else:
                print('Bad request! Try again!')
            if self.role != '':
                return

    def login(self):
        print('Logging in...')
        self._choose_role()

        while True:
            username = input('Enter your username: ')
            password = input('Enter your password: ')
            try:
                self._user_id = self._user.select(columns=('id',), condition=f"username = '{username}' "
                                                         f"AND password = '{password}'")[0][0]
                self._user = self._user.select(condition=f"username = '{username}' "
                                                         f"AND password = '{password}'")
                self._is_success = True
                break
            except:
                self._is_success = False
                print('Bad request! Try again!')

        print('Logged in!')
        return self.role

    def signup(self):
        print('Signing up...')
        while not self._is_success:
            if input('Do you want to exit? y/n: ').lower() == 'y':
                return self.role
            username = input('Enter your username: ')
            password = input('Enter your password: ')
            user_data = [username, password]

            try:
                self._user.insert(tuple(user_data))
                print('Signed up!')
                self._user = self._user.select(condition=f"username = '{user_data[0]}'")[0]
                self._user_id = self._user.select(columns=('id',), condition=f"username = '{username}' "
                                                         f"AND password = '{password}'")[0][0]
                self._is_success = True
            except:
                print('Bad request! Try again!')
                self._is_success = False
        return self.role

    def _get_user(self):
        return self._user

    def check_registration(self):
        if not self._is_success:
            print('Login or register, please!')
            return False

    def buy_ticket(self):
        complex_name = input('Enter complex name: ')
        complex_id = Complex().select(columns=('id',), condition=f"complex_name = '{complex_name}'")[0][0]
        order_data = tuple([str(self._user_id), str(complex_id)])
        Orders().insert(order_data)
        print('Ordered successfully!')

    def logout(self):
        self._user = User()
        self.role = ''
        self._is_success = False
