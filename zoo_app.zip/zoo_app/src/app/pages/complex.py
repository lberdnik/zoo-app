from src.entities import Complex


class ComplexPage:
    def __init__(self):
        self._complex = Complex().select()

    def get_complex(self):
        print('All complexes: ')
        for complex_data in self._complex:
            print("--------------------------------------------------------------------------------------------------")
            print(f"Complex name: {complex_data.complex_name}")

    def create_complex(self):
        complex_data = [input("Enter complex name: "), input("Enter complex entry price: ")]
        try:
            Complex().insert(tuple(complex_data))
            self._complex = Complex().select()
            print('Complex created!')
        except:
            print('Bad data!')
        return

    def update_complex(self):
        complex_id = input("Enter complex id: ")
        attrs = input("Enter attribute, that you want to update: ")
        values = input("Enter value: ")
        try:
            Complex().update({attrs: values}, condition=f"id = '{complex_id}'")
            self._complex = Complex().select()
            print('Complex updated!')
        except:
            print('Bad data!')

    def delete_complex(self):
        complex_id = input("Enter complex id: ")
        try:
            Complex().delete(f"id = '{complex_id}'")
            self._complex = Complex().select()
            print('Complex deleted!')
        except:
            print('Complex does not exist!')
