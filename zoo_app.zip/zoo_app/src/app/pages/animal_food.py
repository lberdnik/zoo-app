from src.entities import Food


class AnimalFoodPage:
    def __init__(self):
        self._animal_food = Food().select()

    def create_food(self):
        food_data = [input('Enter food name: ')]
        try:
            Food().insert(tuple(food_data))
            print('Food created!')
        except:
            print('Bad data!')

    def get_all_food(self):
        print('All food: ')
        for food in self._animal_food:
            print("--------------------------------------------------------------------------------------------------")
            print(f"Food name: {food.food}")

    def update_food(self):
        food_id = input('Enter food id: ')
        attrs = input('Enter attribute, that you want to update: ')
        values = input('Enter value: ')
        try:
            Food().update({attrs: values}, condition=f"id = '{food_id}'")
            print('Food updated!')
        except:
            print('Bad data!')

    def delete_food(self):
        food_id = input('Enter food id: ')
        try:
            Food().delete(condition=f"id = '{food_id}'")
            self._animal_food = Food().select()
            print('Food deleted!')
        except:
            print('Food does not exist!')
