import datetime
from src.entities import Animal, Kind, Country, Placement, AnimalFood
from src.app.pages.constants import ANIMAL_KINDS_REQUEST, ANIMAL_GROUPS_REQUEST


class AnimalPage:
    _animals: list

    def __init__(self):
        self._animals = Animal().select()

    def get_animals(self):
        print('All animals: ')
        for animal in self._animals:
            print("--------------------------------------------------------------------------------------------------")
            print(f"Animal Id: {animal.id}")
            animal_name = Kind().select(columns=('kind',), condition=f"id = '{animal.kind_id}'")[0][0]
            print('Animal name: ', animal_name)
            print(f"Animal description: {animal.description}")
            animal_country = Country().select(columns=('name',), condition=f"id = '{animal.country_id}'")[0][0]
            print(f"Animal country: {animal_country}")
            animal_placement = Placement().select(columns=('name',), condition=f"id = '{animal.placement_id}'")[0][0]
            print(f"Animal placement: {animal_placement}")

    def get_animal_by_name(self):
        name = input('Enter animal name: ')
        try:
            kind_id = Kind().select(columns=('id',), condition=f"kind = '{name}'")[0][0]
            animal = Animal().select(condition=f"kind_id = {kind_id}")[0]
            print(f"Animal Id: {animal.id}")
            print(f"Animal name: {name}")
            print(f"Animal description: {animal.description}")
            print(f"Animal age: {animal.age}")
        except:
            print('Sorry, we didn\'t find this animal')
        return

    def create_animal(self):
        animal_data = [input('Enter animal age: '), input('Enter animal description: '),
                       input('Enter animal gender(M/F): '),
                       str(datetime.datetime.now())]
        placement_name = input('Enter animal placement name: ')
        try:
            placement_id = Placement().select(columns=('id',), condition=f"name = '{placement_name}'")[0][0]
            animal_data.append(placement_id)
        except:
            print('Sorry, we didn\'t find this placement!')
            return
        country_name = input('Enter animal country: ')
        try:
            country_id = Country().select(columns=('id',), condition=f"name = '{country_name}'")[0][0]
            animal_data.append(country_id)
        except:
            print('Sorry, we didn\'t find this country!')
            return
        kind_name = input('Enter animal kind: ')
        try:
            kind_id = Kind().select(columns=('id',), condition=f"kind = '{kind_name}'")[0][0]
            animal_data.append(kind_id)
        except:
            print('Sorry, we didn\'t find this kind')
            return
        try:
            Animal().insert(tuple(animal_data))
            self._animals = Animal().select()
        except:
            print('Sorry, bad data!')
            return
        print('Animal created!')

    def update_animal(self):
        animal_id = input('Enter animal id: ')
        attrs = input("Enter attribute, that you want to update: ")
        values = input("Enter value: ")
        try:
            Animal().update(data={attrs: values}, condition=f"id = '{animal_id}'")
            self._animals = Animal().select()
            print('Animal updated!')
        except:
            print('Sorry, bad data or animal does not exist!')
        return

    def get_animals_info(self):
        print('Animals kinds and classes info: ')
        animals_info = Animal().execute(ANIMAL_KINDS_REQUEST)
        for animal in animals_info:
            print("--------------------------------------------------------------------------------------------------")
            print('Animal id: ', animal[0])
            print('Animal age: ', animal[1])
            print('Animal gender: ', animal[2])
            print('Animal kind: ', animal[3])
            print('Animal class: ', animal[4])

    def get_animal_groups(self):
        print('Animals age groups info: ')
        animal_groups = Animal().execute(ANIMAL_GROUPS_REQUEST)
        for animal in animal_groups:
            print("--------------------------------------------------------------------------------------------------")
            print('Animal id: ', animal[0])
            print('Animal kind id: ', animal[1])
            print('Animal age: ', animal[2])
            print('Animal age group: ', animal[3])

    def create_animal_food(self):
        food_data = [input('Enter animal id: '), input('Enter food id: ')]
        try:
            AnimalFood().insert(tuple(food_data))
            print('Animal created!')
        except:
            print('Bad data!')

    def delete_animal(self):
        animal_id = input('Enter animal id: ')
        try:
            Animal().delete(condition=f"id = '{animal_id}'")
            self._animals = Animal().select()
            print('Animal deleted!')
        except:
            print('Sorry, we didn\'t find this animal!')
        return
