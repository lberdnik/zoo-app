from src.entities import Class


class ClassPage:
    def __init__(self):
        self._class = Class().select()

    def get_classes(self):
        print('All classes: ')
        for class_data in self._class:
            print("--------------------------------------------------------------------------------------------------")
            print(f"Food name: {class_data.class_name}")

    def create_class(self):
        class_data = [input('Enter class name: ')]
        Class().insert(tuple(class_data))
        self._class = Class().select()
        print('Class created!')

    def update_class(self):
        class_id = input("Enter class id: ")
        attrs = input("Enter attribute, that you want to update: ")
        values = input("Enter value: ")
        try:
            Class().update({attrs: values}, condition=f"id = '{class_id}'")
            self._class = Class().select()
        except:
            print("Error updating! Bad data or class does not exist!")
            return
        print("Class updated!")

    def delete_class(self):
        class_id = input('Enter class id: ')
        try:
            Class().delete(f"id = '{class_id}'")
        except:
            print("Class does not exist!")
            return
        print('Class deleted!')
