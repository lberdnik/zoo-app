from src.entities import Country


class CountryPage:
    def __init__(self):
        self._countries = Country().select()

    def get_country(self):
        print('All countries: ')
        for country in self._countries:
            print("--------------------------------------------------------------------------------------------------")
            print(f"Country name: {country.name}")

    def create_country(self):
        country_data = [input('Enter country name: ')]
        try:
            Country().insert(tuple(country_data))
            self._countries = Country().select()
            print('Country created!')
        except:
            print('Bad data!')

    def update_country(self):
        country_id = input('Enter country id: ')
        attrs = input('Enter attribute: ')
        values = input('Enter value: ')
        try:
            Country().update({attrs: values}, condition=f"id = '{country_id}'")
            print('Country updated!')
            self._countries = Country().select()
        except:
            print('Bad data or the country does not exist!')

    def delete_country(self):
        country_id = input('Enter country id: ')
        try:
            Country().delete(condition=f"id = '{country_id}'")
            print('Country deleted!')
            self._countries = Country().select()
        except:
            print('Bad data or the country does not exist!')
