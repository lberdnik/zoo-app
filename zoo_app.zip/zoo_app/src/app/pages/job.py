from src.entities import Job


class JobPage:
    def __init__(self):
        self._job = Job().select()

    def create_job(self):
        job_data = [input('Enter job title: ')]
        try:
            Job().insert(tuple(job_data))
            self._job = Job().select()
            print('Job created!')
        except:
            print('Bad data!')

    def get_jobs(self):
        print('All jobs: ')
        for job in self._job:
            print("--------------------------------------------------------------------------------------------------")
            print('Job title: ', job.job_title)

    def update_job(self):
        job_id = input('Enter job id: ')
        attrs = input('Enter attribute, that you want to change: ')
        values = input('Enter value: ')
        try:
            Job().update({attrs: values}, condition=f"id = '{job_id}'")
            self._job = Job().select()
            print('Job updated!')
        except:
            print('Bad data or job does not exist!')

    def delete_job(self):
        job_id = input('Enter job id: ')
        try:
            Job().delete(condition=f"id = '{job_id}'")
            self._job = Job().select()
            print('Job deleted!')
        except:
            print('Job does not exist!')
