from src.entities import Kind, Class


class KindPage:
    def __init__(self):
        self._kind = Kind().select()

    def get_kinds(self):
        for kind in self._kind:
            print("--------------------------------------------------------------------------------------------------")
            print('Kind: ', kind.kind)
            class_name = Class().select(('class_name',), condition=f"id = '{kind.class_name_id}'")[0][0]
            print('Class name: ', class_name)

    def create_kind(self):
        kind_data = []
        kind_name = input('Enter kind name: ')
        kind_data.append(kind_name)
        class_name = input("Enter class name: ")
        try:
            class_id = Class().select(columns=('id',), condition=f"class_name = '{class_name}'")[0][0]
            kind_data.append(class_id)
        except:
            print('Class not found')

        try:
            Kind().insert(tuple(kind_data))
            self._kind = Kind().select()
            print('Kind created!')
        except:
            print('Bad data!')

    def update_kind(self):
        kind_id = input('Enter kind id: ')
        attrs = input('Enter attribute: ')
        values = input('Enter value: ')
        try:
            Kind().update({attrs: values}, condition=f"id = '{kind_id}'")
            self._kind = Kind().select()
            print('Kind updated!')
        except:
            print('Bad data or the kind does not exist!')

    def delete_kind(self):
        kind_id = input('Enter kind id: ')
        try:
            kind_id = Kind().delete(condition=f"id = '{kind_id}'")
            self._kind = Kind().select()
            print('Kind deleted!')
        except:
            print('Sorry, we didn\'t find this kind!')
        return

