from src.entities import Employee, Job


class EmployeePage:
    def __init__(self):
        self._employees = Employee().select()

    def get_employees(self):
        print('All employees: ')
        for employee in self._employees:
            print("--------------------------------------------------------------------------------------------------")
            print(f"ID: {employee.id}")
            print(f"Surname: {employee.lastname}")
            print(f"Name: {employee.firstname}")
            print(f"Patronymic: {employee.patronymic}")
            print(f"Phone number: {employee.phone_number}")
            job_name = Job().select(columns=('job_title',), condition=f"id = {employee.job_id}")[0][0]
            print(f"Job name: {job_name}")

    def create(self):
        employee_data = []
        lastname = input('Enter employee surname: ')
        employee_data.append(lastname)
        firstname = input('Enter employee firstname: ')
        employee_data.append(firstname)
        patronymic = input('Enter employee patronymic: ')
        employee_data.append(patronymic)
        phone_number = input('Enter employee phone number: ')
        employee_data.append(phone_number)
        job_name = input('Enter employee job name: ')
        try:
            job_id = Job().select(columns=('id',), condition=f"job_title = '{job_name}'")[0][0]
            employee_data.append(job_id)
        except:
            print('Job not found!')
            return
        Employee().insert(tuple(employee_data))
        try:
            Employee().insert(tuple(employee_data))
            print('Employee created!')
            self._employees = Employee().select()
        except:
            print('Bad data! Try again!')
        return

    def update(self):
        employee_id = input('Enter employee id: ')
        attrs = input('Enter employee attribute: ')
        values = input('Enter employee value: ')
        try:
            Employee().update({attrs: values}, condition=f"id = '{employee_id}'")
            self._employees = Employee().select()
            print('Employee updated!')
        except:
            print('Bad data or the employee does not exist!')
        return

    def delete(self):
        employee_id = input('Enter employee id: ')
        try:
            Employee().delete(condition=f"id = '{employee_id}'")
            print('Employee deleted!')
            self._employees = Employee().select()
        except:
            print('Bad data! Try again!')
        return
