from src.entities import Placement, Complex


class PlacementPage:
    def __init__(self):
        self._placement = Placement().select()

    def create_placement(self):
        place_data = [input('Enter placement name: '), input('Enter placement number: '),
                      input('Enter reservoir: '), input('Enter heating: ')]
        complex_name = input('Enter complex name: ')
        try:
            complex_id = Complex().select(columns=('id',), condition=f"complex_name = '{complex_name}'")[0][0]
            place_data.append(complex_id)
            Placement().insert(tuple(place_data))
            self._placement = Placement().select()
            print('Placement created!')
        except:
            print('Bad data!')

    def update_placement(self):
        place_id = input('Enter placement id: ')
        attrs = input('Enter attribute, that you want to update: ')
        values = input('Enter value: ')
        try:
            Placement().update({attrs: values}, condition=f"id = '{place_id}'")
            self._placement = Placement().select()
            print('Placement updated!')
        except:
            print('Bad data or the placement does not exist!')

    def get_placements(self):
        print('All placements: ')
        for placement in self._placement:
            print("--------------------------------------------------------------------------------------------------")
            print(f"Placement name: {placement.name}")

    def delete_placement(self):
        place_id = input('Enter placement id: ')
        try:
            Placement().delete(condition=f"id = '{place_id}'")
            self._placement = Placement().select()
            print('Placement deleted!')
        except:
            print('The placement does not exist!')
