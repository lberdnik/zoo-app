ANIMAL_KINDS_REQUEST = ("SELECT animal.id, animal.age, animal.gender, kind.kind, class.class_name"
                        " AS class FROM animal INNER JOIN kind  ON animal.kind_id = kind.id "
                        "INNER JOIN class  ON kind.class_name_id = class.id;")

ANIMAL_GROUPS_REQUEST = ("SELECT id, kind_id, age, "
                         "CASE "
                         "WHEN age < 1 THEN 'Baby' "
                         "WHEN age >= 1 AND age < 5 THEN 'Young' "
                         "WHEN age >= 5 AND age < 10 THEN 'Adult' "
                         "ELSE 'Senior' END AS age_group "
                         "FROM animal ORDER BY age;")