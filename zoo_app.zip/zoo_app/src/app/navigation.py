from src.app.pages import (LoginPage, AnimalPage, ComplexPage, CountryPage,
                           KindPage, ClassPage, EmployeePage, AnimalFoodPage, JobPage)
from src.app.pages.placement import PlacementPage


class Navigation:
    _user_role: str = ''

    def __init__(self):
        self._user = LoginPage()
        self._animal = AnimalPage()
        self._complex = ComplexPage()
        self._kind = KindPage()
        self._country = CountryPage()
        self._class = ClassPage()
        self._employee = EmployeePage()
        self._placement = PlacementPage()
        self._food = AnimalFoodPage()
        self._job = JobPage()

    def job(self):
        is_work = True
        while is_work:
            command = input('Enter command: ')
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._job.create_job()
            elif command == 'read':
                self._job.get_jobs()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._job.update_job()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._job.delete_job()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')

    def placement(self):
        is_work = True
        while is_work:
            command = input('Enter command: ')
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._placement.create_placement()
            elif command == 'read':
                self._placement.get_placements()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._placement.update_placement()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._placement.delete_placement()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')

    def country(self):
        is_work = True
        while is_work:
            command = input("Enter command: ")
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._country.create_country()
            elif command == 'read':
                self._country.get_country()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._country.update_country()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._country.delete_country()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')

    def complex(self):
        is_work = True
        while is_work:
            command = input('Enter command: ')
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._complex.create_complex()
            elif command == 'read':
                self._complex.get_complex()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._complex.update_complex()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._complex.delete_complex()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')

    def kind(self):
        is_work = True
        while is_work:
            command = input('Enter command: ')
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._kind.create_kind()
            elif command == 'read':
                self._kind.get_kinds()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._kind.update_kind()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._kind.delete_kind()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')


    def user_class(self):
        is_work = True
        while is_work:
            command = input('Enter command: ')
            if command == 'login':
                self._user_role = self._user.login()
            elif command == 'register':
                self._user_role = self._user.signup()
            elif command == 'buy ticket':
                if self._user_role == '':
                    print('Please login or sign up!')
                    continue
                self._user.buy_ticket()
            elif command == 'logout':
                self._user.logout()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command! Try again!')

    def animal_class(self):
        is_work = True
        while is_work:
            command = input('Enter command: ')
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._class.create_class()
            elif command == 'read':
                self._class.get_classes()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._class.update_class()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._class.delete_class()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')

    def animal_food(self):
        is_work = True
        while is_work:
            command = input('Enter command: ')
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._food.create_food()
            elif command == 'read':
                self._food.get_all_food()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._food.update_food()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._food.delete_food()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')

    def animal(self):
        is_work = True
        while is_work:
            command = input("Enter command: ")
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._animal.create_animal()
            elif command == 'read':
                self._animal.get_animals()
            elif command == 'read animal info':
                self._animal.get_animals_info()
            elif command == 'read animal groups':
                self._animal.get_animal_groups()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._animal.update_animal()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._animal.delete_animal()
            elif command == 'create animal food':
                self._animal.create_animal_food()
            elif command == 'get animal by name':
                self._animal.get_animal_by_name()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')

    def employee(self):
        is_work = True
        while is_work:
            command = input('Enter command: ')
            if command == 'create':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._employee.create()
            elif command == 'read':
                self._employee.get_employees()
            elif command == 'update':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._employee.update()
            elif command == 'delete':
                if self._user_role != 'admin':
                    print('Wrong permission!')
                    continue
                self._employee.delete()
            elif command == 'exit':
                is_work = False
            else:
                print('Invalid command!')


