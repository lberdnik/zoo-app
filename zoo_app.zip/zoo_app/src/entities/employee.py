from src.orm.base_model import BaseModel


class Employee(BaseModel):
    id: int
    firstname: str
    lastname: str
    patronymic: str
    phone_number: str
    job_id: int

    def __int__(self):
        super().__init__()
