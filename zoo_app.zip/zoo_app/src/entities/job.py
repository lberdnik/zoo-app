from src.orm.base_model import BaseModel


class Job(BaseModel):
    id: int
    job_title: str

    def __init__(self):
        super().__init__()
