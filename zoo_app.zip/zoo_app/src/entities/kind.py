from src.orm.base_model import BaseModel


class Kind(BaseModel):
    id: int
    kind: str
    class_name_id: int

    def __init__(self):
        super().__init__()
