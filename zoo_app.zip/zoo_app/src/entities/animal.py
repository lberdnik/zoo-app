import datetime
from src.orm.base_model import BaseModel


class Animal(BaseModel):
    id: int
    age: int
    description: str
    gender: str
    arrival_date: datetime.datetime
    placement_id: int
    country_id: int
    kind_id: int

    def __init__(self):
        super().__init__()
