from src.orm.base_model import BaseModel


class Placement(BaseModel):
    id: int
    name: str
    number: int
    reservoir: bool
    heating: bool
    complex_area_id: int

    def __init__(self):
        super().__init__()
