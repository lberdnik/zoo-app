from src.orm.base_model import BaseModel


class Orders(BaseModel):
    id: int
    user_id: int
    complex_id: int

    def __init__(self):
        super().__init__()

