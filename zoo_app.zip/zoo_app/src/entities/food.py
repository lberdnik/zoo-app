from src.orm.base_model import BaseModel


class Food(BaseModel):
    id: int
    food: str

    def __init__(self):
        super().__init__()
