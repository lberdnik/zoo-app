from src.orm.base_model import BaseModel


class User(BaseModel):
    id: int
    username: str
    password: str

    def __init__(self):
        super().__init__()

    def is_logged(self):
        try:
            return bool(self.id)
        except Exception:
            return False
