from src.orm.base_model import BaseModel


class AnimalFood(BaseModel):
    id: int
    animal_id: int
    food_id: int

    def __init__(self):
        super().__init__()

