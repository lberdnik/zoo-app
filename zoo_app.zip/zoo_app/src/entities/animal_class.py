from src.orm.base_model import BaseModel


class Class(BaseModel):
    id: int
    class_name: str

    def __init__(self):
        super().__init__()
