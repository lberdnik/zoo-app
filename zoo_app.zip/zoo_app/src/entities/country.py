from src.orm.base_model import BaseModel


class Country(BaseModel):
    id: int
    name: str

    def __init__(self):
        super().__init__()
