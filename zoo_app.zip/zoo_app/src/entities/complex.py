from src.orm.base_model import BaseModel


class Complex(BaseModel):
    id: int
    complex_name: str
    price: int

    def __init__(self):
        super().__init__()
